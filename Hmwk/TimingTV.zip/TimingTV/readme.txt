1.Please run all the assembly programs for the timing outputted results.

2.According to my system, after being repeated 4194304 times:

	a.The Vector Floating Point assembly program takes 1 sec.
	
	b.The scaled integer assembly program takes 10 sec.
	
3. Regarding to the C++ programs, their run-time are variable. However, the best total time for:
		
	a. The floating program is 15 ms	
	
	b. The scaled integer program is 31 ms